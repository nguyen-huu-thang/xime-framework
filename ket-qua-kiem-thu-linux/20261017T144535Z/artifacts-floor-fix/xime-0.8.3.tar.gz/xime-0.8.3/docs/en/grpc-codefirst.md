# Code-First gRPC

**English** | [Tiếng Việt](../vn/grpc-codefirst.md)

[← Routing](routing.md) · **7/9 - Code-First gRPC** · [Starters →](starters.md)

---

XIME supports two gRPC development modes:

- **Proto-First** (existing) - you write `.proto` files, XIME serves your handwritten servicers.
- **Code-First** (this page) - you write Python controllers and DTOs, XIME generates the `.proto` files for you.

With Code-First, your Python code is the **single source of truth**. You never write or maintain `.proto` files manually.

```text
Controller + DTO  →  xime grpc generate  →  .proto + Python stubs
                                              ↓
                                         GrpcAdapter serves it
```

> **Requires:** `pip install "xime[grpc]"` (adds `grpcio`, `grpcio-tools`, `protobuf`)

---

## Why Code-First?

Two problems with proto-first at scale:

1. **Drift** - you update a Pydantic DTO but forget to update the `.proto`. The two diverge silently.
2. **Duplication** - every field is defined twice: once in Python, once in protobuf.

Code-First eliminates both. The proto is generated from your Python types - it cannot drift, and there is nothing to duplicate.

---

## Quick Start

### 1. Write the controller

```python
# api/grpc/crypto_controller.py
from xime.core.contract import command, stream, UploadStream, DownloadStream
from pydantic import BaseModel

class HashRequest(BaseModel):
    file_id: str

class HashResponse(BaseModel):
    digest: str

class EncryptRequest(BaseModel):
    name: str

class EncryptResponse(BaseModel):
    total: int

class DownloadRequest(BaseModel):
    parts: int

class CryptoController:
    server_id = "default"   # served by the default GrpcAdapter()

    def __init__(self, crypto_service: CryptoService) -> None:
        self.crypto_service = crypto_service

    @command("hash")
    async def hash(self, request: HashRequest) -> HashResponse:
        return await self.crypto_service.hash(request)

    @stream("encrypt")
    async def encrypt(self, request: EncryptRequest, upload: UploadStream) -> EncryptResponse:
        return await self.crypto_service.encrypt(request, upload)

    @stream("download")
    async def download(self, request: DownloadRequest, download: DownloadStream) -> None:
        await self.crypto_service.download(request, download)
```

### 2. Register the package

```python
# config/grpc.py
from xime.adapters.grpc.codefirst import configure_grpc_codefirst

configure_grpc_codefirst(
    packages=["my_service.api.grpc"],
    output_dir="generated",
    lock_file="proto.lock.json",
)
```

### 3. Generate `.proto` files

```bash
xime grpc generate
```

This produces:

```text
generated/
└── default/
    ├── crypto.proto
    └── crypto_pb2.py
    └── crypto_pb2_grpc.py
```

and creates `proto.lock.json` (commit this to git).

### 4. Run the app

```python
# main.py
from xime.adapters.grpc import GrpcAdapter
from xime.core.bootstrap import Application

import config

app = Application()
app.add_config(config)
app.use(GrpcAdapter())

if __name__ == "__main__":
    app.run()
```

`GrpcAdapter` automatically detects and serves all code-first controllers configured via `configure_grpc_codefirst`.

---

## Endpoint Types

The same two decorators from Socket Adapter work here - the same controller can serve both gRPC and UDS if you register it for both.

### `@command` - unary RPC

```python
@command("hash")
async def hash(self, request: HashRequest) -> HashResponse: ...
```

Generated proto:

```protobuf
rpc Hash(HashRequest) returns (HashResponse);
```

### `@stream` + `UploadStream` - client streaming

```python
@stream("encrypt")
async def encrypt(self, request: EncryptRequest, upload: UploadStream) -> EncryptResponse:
    total = 0
    async for chunk in upload:
        total += len(chunk)
    return EncryptResponse(total=total)
```

Generated proto uses a `oneof` wrapper - the first message carries metadata, subsequent messages carry raw bytes:

```protobuf
message EncryptChunk {
    oneof payload {
        EncryptRequest metadata = 1;
        bytes          chunk    = 2;
    }
}

rpc Encrypt(stream EncryptChunk) returns (EncryptResponse);
```

Your business code never sees `EncryptChunk`. XIME handles the marshalling.

### `@stream` + `DownloadStream` - server streaming

```python
@stream("download")
async def download(self, request: DownloadRequest, download: DownloadStream) -> None:
    for i in range(request.parts):
        await download.write(f"part{i}".encode())
```

Generated proto:

```protobuf
message DownloadChunk { bytes chunk = 1; }

rpc Download(DownloadRequest) returns (stream DownloadChunk);
```

This form is for **bytes** - file download, raw export. To stream **typed records**, use
the form below.

### `@stream` + `yield` - TYPED server streaming (0.7.1)

The handler is an **async generator**; every `yield` is one message:

```python
from collections.abc import AsyncIterator

@stream("watch_changed_accounts")
async def watch_changed_accounts(
    self, request: WatchRequest
) -> AsyncIterator[AccountChanged]:
    async for event in self.feed.follow(request.after_sequence):
        yield AccountChanged(sequence=event.sequence, account_id=event.account_id)
```

The generated proto has **no wrapper** - the response is your own DTO:

```protobuf
rpc WatchChangedAccounts(WatchRequest) returns (stream AccountChanged);
```

So a Java peer reads the `.proto` and understands it without knowing anything about
xime's chunk convention.

Three constraints, all reported at **startup** rather than on the first RPC:

| Mistake | Error |
| --- | --- |
| `@command` containing `yield` | `@command` owes exactly one response, so it cannot be an async generator |
| Both a `DownloadStream` parameter and `yield` | Pick one: bytes or typed records |
| Missing `-> AsyncIterator[<BaseModel>]` | The yielded model IS the streamed message; it cannot be inferred |

**Cleanup when the client leaves:** the framework calls `aclose()` on your generator as
soon as the client cancels, so a `finally:` block (closing a DB session, releasing a lock)
runs right then instead of whenever the garbage collector gets to it. Write `try/finally`
as usual.

---

## Field Number Stability

> This is the most important thing about Code-First gRPC.

Protobuf identifies fields by **number**, not name. If the generator reassigns numbers when regenerating, old clients silently misread responses - a hard-to-debug corruption.

XIME solves this with `proto.lock.json`:

```json
{
  "messages": {
    "HashRequest": {
      "fields": { "file_id": 1 },
      "reserved_numbers": [],
      "reserved_names": []
    }
  }
}
```

**Rules:**

- Fields already in the lock keep their number forever.
- New fields get the next available number, skipping reserved ones.
- Deleted fields become `reserved` - their number is never reused.

**Commit `proto.lock.json` to git.** It is part of your source of truth.

```protobuf
// If you delete "email" from UserResponse:
message UserResponse {
    reserved 3;       // "email" was field 3
    reserved "email";
    int64  id = 1;
    string username = 2;
    string role = 4;
}
```

---

## Type Mapping

| Python | Proto | Notes |
| --- | --- | --- |
| `str` | `string` | |
| `bytes` | `bytes` | |
| `bool` | `bool` | |
| `int` | `int64` | default; override with `Annotated` |
| `float` | `double` | |
| `list[T]` | `repeated <T>` | |
| `dict[K, V]` | `map<K, V>` | K must be scalar |
| `Optional[T]` / `T \| None` | `optional <T>` | proto3 explicit presence |
| `datetime.datetime` | `google.protobuf.Timestamp` | |
| `Decimal` | `string` | avoids precision loss |
| `UUID` | `string` | |
| `IntEnum` / `StrEnum` | `enum` | members become enum values |
| nested `BaseModel` | `message <Name>` | |

**Override integer type** with `Annotated`:

```python
from typing import Annotated
from xime.adapters.grpc.codefirst import ProtoInt32, ProtoUInt64

class Page(BaseModel):
    size:  Annotated[int, ProtoInt32]   # → int32
    cursor: Annotated[int, ProtoUInt64] # → uint64
```

Unsupported types raise `UnsupportedTypeError` at generate time, not at runtime.

---

## Shared DTOs → `common.proto`

When a DTO is used by two or more controllers in the same `server_id`, XIME places it in `common.proto` automatically:

```text
generated/default/
├── crypto.proto     # imports common.proto
├── user.proto       # imports common.proto
└── common.proto     # shared: UserResponse, PageInfo, ...
```

---

## CLI

### Generate

```bash
xime grpc generate           # generate .proto + run protoc
xime grpc generate --no-protoc  # only generate .proto files (skip protoc)
```

### Check (use in CI)

```bash
xime grpc check
```

Compares the proto that *would* be generated against what is on disk. Exits with code 1 if anything differs. Use this as a CI gate to catch "DTO changed but proto not regenerated":

```text
Proto Out Of Date
  File: generated/default/crypto.proto
  Hint: run `xime grpc generate`
```

---

## Multi-Server

Just like the HTTP and gRPC proto-first adapters, code-first controllers are routed to the correct server by `server_id`:

```python
class PublicCryptoController:
    server_id = "default"     # served by the default GrpcAdapter()
    ...

class InternalCryptoController:
    server_id = "internal"    # served by GrpcAdapter("internal")
    ...
```

```python
app.use(GrpcAdapter())                         # serves server_id="default"
app.use(GrpcAdapter("internal"))   # port from process.grpc.internal in application.yml
```

> **`server_id` must match a registered adapter.** The default `GrpcAdapter()`
> has `server_id="default"` - it does **not** serve a controller whose
> `server_id` is something else. If a code-first controller targets a `server_id`
> that no `GrpcAdapter` serves (e.g. `server_id="public"` while only the default
> adapter is registered), XIME **fails fast at startup** with a clear message,
> instead of starting a server that silently answers every RPC with
> `UNIMPLEMENTED`. Either register a matching `GrpcAdapter("public", port=...)`
> or change the controller's `server_id`.

---

## Coexistence with Proto-First

Code-First and proto-first servicers can live in the same `GrpcAdapter`. Configure each independently:

```python
# config/grpc.py - proto-first
from xime.adapters.grpc import configure_grpc_services
configure_grpc_services("my_service.api.grpc.proto_first")

# config/grpc_codefirst.py - code-first
from xime.adapters.grpc.codefirst import configure_grpc_codefirst
configure_grpc_codefirst(packages=["my_service.api.grpc.codefirst"])
```

---

## TLS / mTLS

Enable server TLS in `application.yml`. The `default` server reads `grpc.tls`;
other servers read `grpc.servers.<server_id>.tls`:

```yaml
grpc:
  port: 50051
  tls:
    enabled: true
    mutual: true                 # true = require client cert (mTLS)
    cert_file: certs/server.crt  # static mode: read certs from files
    key_file:  certs/server.key
    ca_file:   certs/ca.crt
```

**Dynamic mTLS (rotation without restart).** When certificates are issued
dynamically (e.g. by an internal certificate authority, and rotated
periodically), register a
`GrpcCertificateProvider` instead of declaring files. The provider reads the
current cert from memory; the framework re-asks it on **every new TLS
handshake**, so rotation needs no restart and never cuts established sessions:

```python
# config/grpc.py
from xime.adapters.grpc import configure_grpc_tls

configure_grpc_tls(provider=MyCertificateProvider)
#   provider is a DI class with version() -> str and current() -> ServerCertificates
```

```yaml
grpc:
  tls:
    enabled: true
    mutual: true     # cert_file/key_file not needed with a provider
```

The provider applies to every server; override one server with
`configure_grpc_tls(provider=PublicCaProvider, server_id="public")` (e.g.
internal servers use certs from a private CA, the public server uses a public
CA).

---

## Calling from another service

This page is the **server** side. To have another service **call** this
code-first server as if it were a local function - generate a typed client SDK,
wire it into DI, share the dynamic cert - see
[gRPC Client SDK + Dynamic mTLS](grpc-client.md).

---

## Installation

```bash
pip install "xime[grpc]"   # adds grpcio, grpcio-tools, protobuf
```

---

[← Routing](routing.md) · **7/9 - Code-First gRPC** · [Starters →](starters.md) · [gRPC Client SDK →](grpc-client.md)
